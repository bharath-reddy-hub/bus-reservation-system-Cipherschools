package com.shivajivarma.brs.controller;

/**
 * @author <a href="http://shivajivarma.com" target="_blank">Shivaji Varma</a>
 */
public abstract class BaseController {}