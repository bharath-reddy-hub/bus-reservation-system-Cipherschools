package com.shivajivarma.brs.model.service;

/**
 * @author <a href="http://shivajivarma.com" target="_blank">Shivaji Varma</a>
 */
public interface Service {

}
